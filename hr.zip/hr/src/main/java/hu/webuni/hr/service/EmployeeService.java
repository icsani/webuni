package hu.webuni.hr.service;

import hu.webuni.hr.model.Employee;

public interface EmployeeService {
	
	public int getPayRaisePercent(Employee employee);

}
